"""
Runs one image through all four downloaded anemia models and prints
whatever each one returns.

The four repos are not built the same way. Two look like standard
image classifiers and load through transformers' pipeline() with no
extra work. The other two use custom formats (a scikit-learn model on
handcrafted features, a fusion architecture with its own class). This
script tries the generic path first for every model and tells you
plainly when a model needs its own loading code instead of guessing
at it.

Run download_anemia_models.py first, then:
    python compare_models.py path/to/photo.jpg
"""

import sys
import os
import json

MODELS = {
    "nail-anemia-detector": "JetX-GT/nail-anemia-detector",
    "anemia-palor-detection": "galihkjaya/anemia-palor-detection",
    "vit-anemia-conjunctiva": "thismad/vit-anemia-conjunctiva",
    "Attention_Fusion_Anemia_Model": "DrateHillary/Attention_Fusion_Anemia_Model",
}


def try_pipeline(folder, repo_id, image_path):
    """Attempt the standard transformers image-classification pipeline.
    Works for plain image classifiers. Raises for anything else."""
    from transformers import pipeline
    clf = pipeline("image-classification", model=folder)
    return clf(image_path)


def try_sklearn(folder, image_path):
    """Attempt to load a scikit-learn model saved with joblib.
    Only works if the repo ships a matching feature-extraction step,
    which this script does not reimplement. Use the repo's own
    inference.py for that model instead."""
    import joblib
    model_files = [f for f in os.listdir(folder) if f.endswith((".joblib", ".pkl"))]
    if not model_files:
        raise FileNotFoundError("no .joblib or .pkl file in this folder")
    joblib.load(os.path.join(folder, model_files[0]))
    raise NotImplementedError(
        "model loaded, but feature extraction is repo-specific. "
        "Run this repo's own inference.py instead of this generic script."
    )


def run_one(name, repo_id, image_path):
    folder = name
    if not os.path.isdir(folder):
        return f"not downloaded (run download_anemia_models.py first)"

    try:
        result = try_pipeline(folder, repo_id, image_path)
        return json.dumps(result[:2])
    except Exception as pipeline_error:
        try:
            return try_sklearn(folder, image_path)
        except Exception as fallback_error:
            return (
                f"generic pipeline failed ({pipeline_error}). "
                f"Check {folder}/README.md or {folder}/inference.py "
                f"for how this repo expects to be called."
            )


def main():
    if len(sys.argv) != 2:
        print("Usage: python compare_models.py path/to/photo.jpg")
        sys.exit(1)

    image_path = sys.argv[1]
    if not os.path.isfile(image_path):
        print(f"No file at {image_path}")
        sys.exit(1)

    print(f"Running {image_path} through {len(MODELS)} models\n")
    for folder_name, repo_id in MODELS.items():
        print(f"[{repo_id}]")
        print(run_one(folder_name, repo_id, image_path))
        print()


if __name__ == "__main__":
    main()
